var count = 9;
var countElement = document.querySelector("user1, h3");

function addlike() {
    count++;
    countElement.innerText = count + " like(s)";
}



var count2 = 12;
var countElement2 = document.getElementById("2");
function addlike2() {
    count2++;
    countElement2.innerText = count2 + " like(s)";
}


var count3 = 9;
var countElement3 = document.getElementById("3")

function addlike3() {
    count3++;
    countElement3.innerText = count3 + " like(s)";
}



